import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { loadouts } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(loadouts).where(eq(loadouts.id, 1));
    return NextResponse.json({ data: rows[0]?.data ?? null });
  } catch {
    return NextResponse.json({ data: null });
  }
}

export async function PUT(req: Request) {
  try {
    const body = (await req.json()) as { data: unknown };
    if (!body || typeof body !== "object" || !("data" in body)) {
      return NextResponse.json({ error: "invalid" }, { status: 400 });
    }
    await db
      .insert(loadouts)
      .values({ id: 1, data: body.data })
      .onConflictDoUpdate({ target: loadouts.id, set: { data: body.data, updatedAt: new Date() } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
